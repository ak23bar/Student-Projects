
def EvenorOdd(x):
    if x % 2 == 0:
        return "even"
    else :
        return "odd"
        
z=int(input("pick a numbor "))
print(EvenorOdd(z))