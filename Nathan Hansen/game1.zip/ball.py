#ball.py
import pygame
import math
import sys
import random
#yteuswyrhthdyetfyfthiwesdoertrduywja7irdusywatyutsyuyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy

pygame.init()

screen_with=1000
screen_height=1000
screen=pygame.display.set_mode((screen_with, screen_height))
pygame.display.set_caption("chess battle balls")

#colers and cba
white=(255,255,255)
red=(255,0,0)
blue=(0,0,255)